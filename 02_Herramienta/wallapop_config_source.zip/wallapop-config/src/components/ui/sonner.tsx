import { Toaster as Sonner } from "sonner"

type ToasterProps = React.ComponentProps<typeof Sonner>

const Toaster = ({ ...props }: ToasterProps) => {
  return (
    <Sonner
      theme="light"
      position="bottom-center"
      className="toaster group"
      toastOptions={{
        classNames: {
          toast:
            "group toast group-[.toaster]:bg-[hsl(var(--green-deep))] group-[.toaster]:text-[hsl(var(--paper-2))] group-[.toaster]:border-[hsl(var(--green))] group-[.toaster]:shadow-2xl group-[.toaster]:rounded-full group-[.toaster]:font-medium",
          description: "group-[.toast]:text-[hsl(var(--paper-2))]/80",
          actionButton: "group-[.toast]:bg-[hsl(var(--terra))] group-[.toast]:text-white",
          cancelButton: "group-[.toast]:bg-muted group-[.toast]:text-muted-foreground",
        },
      }}
      {...props}
    />
  )
}

export { Toaster }
