import { highlightYaml } from "@/lib/config";
import { FileCode2 } from "lucide-react";

export function YamlPreview({ yaml }: { yaml: string }) {
  return (
    <div className="slidein mt-5 overflow-hidden rounded-[20px] border-[1.5px] border-[hsl(200_24%_24%)] shadow-[0_18px_40px_-22px_rgba(20,45,55,.5)]">
      <div className="flex items-center gap-2.5 border-b border-white/10 bg-[hsl(var(--green-deep))] px-5 py-3">
        <FileCode2 className="h-4 w-4 text-[hsl(var(--gold))]" />
        <span className="font-display text-[1.05rem] font-semibold text-[hsl(var(--paper-2))]">config.yaml</span>
        <span className="ml-auto flex gap-1.5">
          <i className="block h-2.5 w-2.5 rounded-full bg-[hsl(var(--terra))]" />
          <i className="block h-2.5 w-2.5 rounded-full bg-[hsl(var(--gold))]" />
          <i className="block h-2.5 w-2.5 rounded-full bg-[hsl(173_70%_45%)]" />
        </span>
      </div>
      <pre
        className="yaml-scroll font-mono-c m-0 max-h-[440px] overflow-auto bg-[hsl(200_28%_12%)] p-5 text-[0.84rem] leading-[1.6] text-[#dfe8ec]"
        style={{ whiteSpace: "pre", tabSize: 2 }}
        dangerouslySetInnerHTML={{ __html: highlightYaml(yaml) }}
      />
    </div>
  );
}
