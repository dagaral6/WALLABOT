import * as React from "react";
import { cn } from "@/lib/utils";

// Field control base classes
export function inputCls(invalid?: boolean) {
  return cn(
    "h-11 rounded-xl border-[1.5px] bg-[hsl(0_0%_100%)] px-3.5 text-[0.97rem] shadow-none transition-all",
    "focus-visible:ring-4 focus-visible:ring-[hsl(var(--green)/.16)] focus-visible:border-[hsl(var(--green))]",
    invalid && "border-destructive bg-destructive/[0.06] focus-visible:ring-destructive/15"
  );
}

export function Meeple({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" className={className}>
      <circle cx="12" cy="5" r="3" />
      <path d="M5 21c0-4 3-7 7-7s7 3 7 7" />
      <path d="M3 14l5-2M21 14l-5-2" />
    </svg>
  );
}

interface SectionCardProps {
  index?: React.ReactNode;
  title: string;
  note?: React.ReactNode;
  icon?: React.ReactNode;
  delay?: number;
  children: React.ReactNode;
  className?: string;
}

export function SectionCard({ index, title, note, icon, delay = 0, children, className }: SectionCardProps) {
  return (
    <section
      className={cn(
        "rise relative rounded-[20px] border-[1.5px] border-border bg-card p-6 sm:p-7",
        "shadow-[0_1px_0_rgba(255,255,255,.7)_inset,0_14px_36px_-22px_rgba(20,45,55,.32)]",
        className
      )}
      style={{ animationDelay: `${delay}ms` }}
    >
      <div className="mb-1 flex items-center gap-3.5">
        {index != null && (
          <span className="grid h-9 w-9 flex-none place-items-center rounded-xl bg-[hsl(var(--green))] font-display text-[1.05rem] font-bold text-[hsl(var(--paper-2))] shadow-[0_6px_14px_-6px_hsl(var(--green)/.8)]">
            {index}
          </span>
        )}
        <h2 className="font-display text-[1.4rem] font-bold leading-tight tracking-[-0.01em] text-[hsl(var(--green-deep))]">
          {title}
        </h2>
        {icon && <span className="ml-auto text-[hsl(var(--brown))]/70">{icon}</span>}
      </div>
      {note && <p className="mb-5 ml-[3.1rem] text-[0.92rem] leading-snug text-[hsl(var(--brown))]">{note}</p>}
      {children}
    </section>
  );
}

interface FieldProps {
  label: React.ReactNode;
  required?: boolean;
  optional?: boolean;
  hint?: React.ReactNode;
  error?: string;
  htmlFor?: string;
  className?: string;
  children: React.ReactNode;
}

export function Field({ label, required, optional, hint, error, htmlFor, className, children }: FieldProps) {
  return (
    <div className={className}>
      <label htmlFor={htmlFor} className="mb-1.5 block text-[0.88rem] font-semibold text-foreground">
        {label}
        {required && <span className="text-[hsl(var(--gold))]"> ●</span>}
        {optional && <span className="font-medium text-[hsl(var(--brown))]"> (opcional)</span>}
      </label>
      {children}
      {hint && <p className="mt-1.5 text-[0.8rem] leading-snug text-[hsl(var(--brown))]">{hint}</p>}
      {error && <p className="mt-1.5 text-[0.8rem] font-semibold text-destructive">{error}</p>}
    </div>
  );
}

export function ToggleChip({
  active,
  onClick,
  title,
  children,
}: {
  active: boolean;
  onClick: () => void;
  title?: string;
  children: React.ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      title={title}
      aria-pressed={active}
      className={cn(
        "inline-flex items-center gap-2 rounded-xl border-[1.5px] px-3.5 py-2 text-[0.86rem] font-semibold transition-all",
        active
          ? "border-[hsl(var(--green))] bg-[hsl(173_62%_93%)] text-[hsl(var(--green-deep))]"
          : "border-border bg-[hsl(0_0%_100%)] text-[hsl(var(--brown))] hover:border-[hsl(var(--primary))] hover:-translate-y-px"
      )}
    >
      <span
        className={cn(
          "h-2 w-2 rounded-[3px] transition-colors",
          active ? "bg-[hsl(var(--green))]" : "bg-[hsl(200_14%_78%)]"
        )}
      />
      {children}
    </button>
  );
}

// city / preset pill
export function Pill({ onClick, children }: { onClick: () => void; children: React.ReactNode }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="rounded-full border-[1.5px] border-border bg-[hsl(200_24%_97%)] px-3.5 py-1.5 text-[0.84rem] font-medium text-[hsl(var(--green-deep))] transition-all hover:-translate-y-px hover:border-[hsl(var(--primary))] hover:bg-[hsl(173_60%_93%)]"
    >
      {children}
    </button>
  );
}
