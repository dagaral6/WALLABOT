import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Field, ToggleChip, Meeple, inputCls } from "@/components/bits";
import { CATS, type Game, type Category } from "@/lib/config";
import { Trash2 } from "lucide-react";

interface Props {
  game: Game;
  index: number;
  errors: Set<string>;
  onChange: (patch: Partial<Game>) => void;
  onRemove: () => void;
  canRemove: boolean;
}

export function GameCard({ game, index, errors, onChange, onRemove, canRemove }: Props) {
  const has = (k: string) => errors.has(`${game.id}:${k}`);

  const toggleWant = (c: Category) => {
    const next = game.want.includes(c) ? game.want.filter((w) => w !== c) : [...game.want, c];
    onChange({ want: next });
  };

  return (
    <div className="pop group relative mb-4 overflow-hidden rounded-2xl border-[1.5px] border-border bg-white p-5 shadow-[0_2px_10px_-6px_rgba(20,45,55,.18)] transition-all hover:border-[hsl(var(--primary)/.5)] hover:shadow-[0_10px_28px_-16px_rgba(20,45,55,.35)] sm:p-6">
      <div className="mb-4 flex items-center justify-between">
        <span className="flex items-center gap-2 font-display text-[1.02rem] font-bold text-[hsl(var(--green-deep))]">
          <span className="grid h-7 w-7 place-items-center rounded-lg bg-[hsl(var(--accent))] text-[hsl(var(--primary))]">
            <Meeple className="h-4 w-4" />
          </span>
          Juego <span className="tabular-nums">{index + 1}</span>
        </span>
        <Button
          type="button"
          variant="outline"
          size="sm"
          onClick={onRemove}
          disabled={!canRemove}
          className="h-8 gap-1.5 rounded-lg border-border bg-white text-[hsl(var(--brown))] hover:border-destructive hover:bg-destructive/[0.06] hover:text-destructive disabled:opacity-40"
        >
          <Trash2 className="h-3.5 w-3.5" />
          Quitar
        </Button>
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <Field
          className="sm:col-span-2"
          label="Nombre para el email"
          required
          error={has("name") ? "Ponle un nombre." : undefined}
        >
          <Input
            value={game.name}
            onChange={(e) => onChange({ name: e.target.value })}
            placeholder="Ej. Wingspan"
            className={inputCls(has("name"))}
          />
        </Field>

        <Field
          className="sm:col-span-2"
          label="Qué buscar en Wallapop"
          required
          hint="Las palabras que escribirías en el buscador de Wallapop."
          error={has("keywords") ? "Escribe qué buscar." : undefined}
        >
          <Input
            value={game.keywords}
            onChange={(e) => onChange({ keywords: e.target.value })}
            placeholder="Ej. wingspan · carcassonne posadas catedrales"
            className={inputCls(has("keywords"))}
          />
        </Field>

        <Field label="Precio máximo" optional hint="Los lotes te llegan aunque lo superen.">
          <div className="relative">
            <span className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 font-semibold text-[hsl(var(--brown))]">€</span>
            <Input
              type="number"
              min={0}
              step="any"
              value={game.maxPrice}
              onChange={(e) => onChange({ maxPrice: e.target.value })}
              placeholder="35"
              className={inputCls() + " pl-7"}
            />
          </div>
        </Field>

        <Field label="Precio mínimo" optional>
          <div className="relative">
            <span className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 font-semibold text-[hsl(var(--brown))]">€</span>
            <Input
              type="number"
              min={0}
              step="any"
              value={game.minPrice}
              onChange={(e) => onChange({ minPrice: e.target.value })}
              placeholder="0"
              className={inputCls() + " pl-7"}
            />
          </div>
        </Field>

        <Field
          className="sm:col-span-2"
          label="Qué quieres recibir"
          optional
          error={has("want") ? "Marca al menos una opción." : undefined}
        >
          <div className="flex flex-wrap gap-2.5">
            {CATS.map((c) => (
              <ToggleChip key={c.value} active={game.want.includes(c.value)} onClick={() => toggleWant(c.value)} title={c.hint}>
                {c.label}
              </ToggleChip>
            ))}
          </div>
        </Field>

        <Field
          className="sm:col-span-2"
          label="Palabras a excluir"
          optional
          hint="Separadas por comas. Descarta anuncios cuyo título las contenga."
        >
          <Input
            value={game.exclude}
            onChange={(e) => onChange({ exclude: e.target.value })}
            placeholder="junior, infantil"
            className={inputCls()}
          />
        </Field>
      </div>
    </div>
  );
}
