import { useMemo, useRef, useState } from "react";
import { toast } from "sonner";
import { Toaster } from "@/components/ui/sonner";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { SectionCard, Field, Pill, inputCls, Meeple } from "@/components/bits";
import { GameCard } from "@/components/GameCard";
import { YamlPreview } from "@/components/YamlPreview";
import {
  type AppState,
  type Game,
  initialState,
  emptyGame,
  buildYAML,
  validate,
  parseConfig,
  configToState,
  buildSummary,
  slugify,
  RECIPIENT_EMAIL,
  CITIES,
  MODELS,
} from "@/lib/config";
import {
  Mail, MapPin, Boxes, Cpu, Plus, Download, Copy, Eye, EyeOff,
  Upload, RotateCcw, Clock, AlertTriangle, AtSign, Sparkles, Send, Bell,
} from "lucide-react";

const EMPTY = new Set<string>();

export default function App() {
  const [state, setState] = useState<AppState>(initialState);
  const [validated, setValidated] = useState(false);
  const [showPreview, setShowPreview] = useState(false);
  const [loadName, setLoadName] = useState("");
  const fileRef = useRef<HTMLInputElement>(null);
  const summaryRef = useRef<HTMLDivElement>(null);
  const nameRef = useRef<HTMLInputElement>(null);
  const [sent, setSent] = useState(false);

  const yaml = useMemo(() => buildYAML(state), [state]);
  const result = useMemo(() => validate(state), [state]);
  const errors = validated ? result.fields : EMPTY;

  const who = state.name.trim();
  const fileSlug = slugify(who);
  const filename = fileSlug ? `config_${fileSlug}.yaml` : "config.yaml";
  const subject = "ALERTA WALLAPOP" + (who ? " " + who.toUpperCase() : "");

  const setEmail = (p: Partial<AppState["email"]>) => setState((s) => ({ ...s, email: { ...s.email, ...p } }));
  const setGeneral = (p: Partial<AppState["general"]>) => setState((s) => ({ ...s, general: { ...s.general, ...p } }));
  const setClassifier = (p: Partial<AppState["classifier"]>) => setState((s) => ({ ...s, classifier: { ...s.classifier, ...p } }));
  const setName = (v: string) => { setSent(false); setState((s) => ({ ...s, name: v })); };
  const setGame = (id: string, p: Partial<Game>) =>
    setState((s) => ({ ...s, games: s.games.map((g) => (g.id === id ? { ...g, ...p } : g)) }));
  const addGame = () => setState((s) => ({ ...s, games: [...s.games, emptyGame()] }));
  const removeGame = (id: string) => setState((s) => ({ ...s, games: s.games.filter((g) => g.id !== id) }));

  function handleDownload() {
    if (!result.ok) {
      setValidated(true);
      toast.error("Revisa los campos marcados en rojo");
      requestAnimationFrame(() => summaryRef.current?.scrollIntoView({ behavior: "smooth", block: "center" }));
      return;
    }
    const blob = new Blob([yaml], { type: "text/yaml;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
    toast.success(filename + " descargado ✓");
  }

  async function handleCopy() {
    try {
      await navigator.clipboard.writeText(yaml);
      toast.success("Copiado al portapapeles ✓");
    } catch {
      const ta = document.createElement("textarea");
      ta.value = yaml;
      document.body.appendChild(ta);
      ta.select();
      try {
        document.execCommand("copy");
        toast.success("Copiado ✓");
      } catch {
        toast.error("No se pudo copiar");
      }
      ta.remove();
    }
  }

  async function handleFile(ev: React.ChangeEvent<HTMLInputElement>) {
    const f = ev.target.files?.[0];
    if (!f) return;
    try {
      const text = await f.text();
      const data = parseConfig(text);
      if (!data || typeof data !== "object") throw new Error("bad");
      setState(configToState(data));
      setValidated(false);
      setLoadName(f.name);
      toast.success('"' + f.name + '" cargado ✓');
    } catch {
      toast.error("No se pudo leer el archivo. ¿Es un config válido?");
    } finally {
      if (fileRef.current) fileRef.current.value = "";
    }
  }

  function handleReset() {
    setState(initialState());
    setValidated(false);
    setLoadName("");
    toast("Formulario reiniciado");
  }

  function buildMessage() {
    return buildSummary(state) + "\n\n----- " + filename + " -----\n\n" + yaml;
  }

  function openGmailCompose() {
    const gmail =
      "https://mail.google.com/mail/?view=cm&fs=1&tf=1" +
      "&to=" + encodeURIComponent(RECIPIENT_EMAIL) +
      "&su=" + encodeURIComponent(subject) +
      "&body=" + encodeURIComponent(buildMessage());
    window.location.href = gmail;
  }

  function handleSend() {
    if (!who) {
      setValidated(true);
      toast.error("Escribe tu nombre para identificar el envío");
      requestAnimationFrame(() => {
        nameRef.current?.scrollIntoView({ behavior: "smooth", block: "center" });
        nameRef.current?.focus();
      });
      return;
    }
    if (!result.ok) {
      setValidated(true);
      toast.error("Revisa los campos marcados en rojo");
      requestAnimationFrame(() => summaryRef.current?.scrollIntoView({ behavior: "smooth", block: "center" }));
      return;
    }
    openGmailCompose();
    setSent(true);
  }

  const e = state.email;
  const gameCount = state.games.length;
  const problems = [...new Set(result.problems)];

  return (
    <div className="grain relative min-h-screen font-body">
      <Toaster />

      <div className="relative z-10 mx-auto max-w-[840px] px-5 pb-44">
        {/* Header */}
        <header className="pt-12 text-center sm:pt-14">
          <div className="mb-5 flex justify-center">
            <span className="inline-flex items-center gap-2 rounded-full bg-[hsl(var(--primary))] px-4 py-1.5 text-[0.78rem] font-bold uppercase tracking-[0.06em] text-white shadow-[0_10px_22px_-10px_hsl(var(--primary)/.8)]">
              <Bell className="h-3.5 w-3.5" /> Alertas de segunda mano
            </span>
          </div>
          <h1 className="font-display text-[clamp(2.3rem,7vw,3.5rem)] font-extrabold leading-[1.0] tracking-[-0.03em]">
            <span className="text-[hsl(var(--primary))]">wallapop</span>
            <span className="text-[hsl(var(--green-deep))]"> Alerts</span>
          </h1>
          <p className="mx-auto mt-3 max-w-[470px] text-[1.02rem] text-[hsl(var(--brown))]">
            Dinos qué juegos de mesa buscas y recibe un aviso en cuanto aparezcan. Sin instalar nada.
          </p>
          <div className="mt-5 flex flex-wrap items-center justify-center gap-x-5 gap-y-1.5 text-[0.85rem] text-[hsl(var(--brown))]">
            <span className="inline-flex items-center gap-1.5">
              <span className="font-bold text-[hsl(var(--terra))]">●</span> campo obligatorio
            </span>
            <span>
              los marcados <i>(opcional)</i> puedes dejarlos vacíos
            </span>
          </div>
        </header>

        {/* Load */}
        <SectionCard
          index={<RotateCcw className="h-4 w-4" />}
          title="Cargar configuración"
          icon={<Upload className="h-5 w-5" />}
          note="¿Tienes un config.yaml o config.json anterior? Cárgalo aquí para editarlo."
          delay={40}
          className="mt-8"
        >
          <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
            <input
              ref={fileRef}
              type="file"
              accept=".yaml,.yml,.json"
              onChange={handleFile}
              className="block w-full flex-1 cursor-pointer rounded-xl border-[1.5px] border-border bg-[hsl(0_0%_100%)] px-3.5 py-2.5 text-[0.92rem] text-[hsl(var(--brown))] file:mr-3 file:cursor-pointer file:rounded-lg file:border-0 file:bg-[hsl(var(--green))] file:px-4 file:py-2 file:font-semibold file:text-[hsl(var(--paper-2))] hover:file:bg-[hsl(174_82%_30%)]"
            />
            {loadName && (
              <Button type="button" variant="outline" onClick={handleReset} className="h-11 flex-none gap-2 rounded-xl border-border bg-[hsl(200_24%_97%)] font-semibold text-[hsl(var(--green-deep))]">
                <RotateCcw className="h-4 w-4" /> Empezar de cero
              </Button>
            )}
          </div>
          {loadName && (
            <p className="mt-3 text-[0.85rem] font-medium text-[hsl(var(--green))]">
              Editando <b>{loadName}</b> — haz cambios y vuelve a descargar.
            </p>
          )}
        </SectionCard>

        {/* Email */}
        <SectionCard
          index={1}
          title="Tu correo"
          icon={<Mail className="h-5 w-5" />}
          note="La dirección donde quieres recibir los avisos cuando aparezca un juego."
          delay={110}
          className="mt-6"
        >
          <Field label="Recibir los avisos en" required error={errors.has("recipient") ? "Introduce un correo válido." : undefined}>
            <div className="relative">
              <AtSign className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-[hsl(var(--brown))]" />
              <Input
                type="email"
                value={e.recipient}
                onChange={(ev) => setEmail({ recipient: ev.target.value })}
                placeholder="tucorreo@gmail.com"
                className={inputCls(errors.has("recipient")) + " pl-10"}
              />
            </div>
          </Field>

          <Disclosure label="Ajustes del servidor (avanzado · no suele hacer falta tocarlo)">
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <Field label="Servidor SMTP" required error={errors.has("smtpHost") ? "No puede estar vacío." : undefined}>
                <Input value={e.smtpHost} onChange={(ev) => setEmail({ smtpHost: ev.target.value })} className={inputCls(errors.has("smtpHost"))} />
              </Field>
              <Field label="Puerto" required error={errors.has("smtpPort") ? "Pon un número de puerto." : undefined}>
                <Input type="number" min={1} value={e.smtpPort} onChange={(ev) => setEmail({ smtpPort: ev.target.value })} className={inputCls(errors.has("smtpPort"))} />
              </Field>
            </div>
          </Disclosure>
        </SectionCard>

        {/* General */}
        <SectionCard
          index={2}
          title="Zona y frecuencia"
          icon={<MapPin className="h-5 w-5" />}
          note="Desde dónde se busca y cada cuánto se comprueba Wallapop."
          delay={180}
          className="mt-6"
        >
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <Field className="sm:col-span-2" label="Cada cuántos minutos comprobar" required hint="Recomendado: entre 5 y 15 minutos." error={errors.has("interval") ? "Pon un número de minutos (mínimo 1)." : undefined}>
              <div className="relative">
                <Clock className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-[hsl(var(--brown))]" />
                <Input type="number" min={1} value={state.general.interval} onChange={(ev) => setGeneral({ interval: ev.target.value })} className={inputCls(errors.has("interval")) + " pl-10"} />
              </div>
            </Field>
            <Field label="Latitud" required error={errors.has("lat") ? "Falta la latitud." : undefined}>
              <Input type="number" step="any" value={state.general.lat} onChange={(ev) => setGeneral({ lat: ev.target.value })} className={inputCls(errors.has("lat"))} />
            </Field>
            <Field label="Longitud" required error={errors.has("lon") ? "Falta la longitud." : undefined}>
              <Input type="number" step="any" value={state.general.lon} onChange={(ev) => setGeneral({ lon: ev.target.value })} className={inputCls(errors.has("lon"))} />
            </Field>
          </div>
          <p className="mb-2.5 mt-4 text-[0.8rem] text-[hsl(var(--brown))]">Centro de búsqueda. Elige una ciudad o escribe las coordenadas a mano:</p>
          <div className="flex flex-wrap gap-2">
            {CITIES.map((c) => (
              <Pill key={c.name} onClick={() => setGeneral({ lat: String(c.lat), lon: String(c.lon) })}>
                📍 {c.name}
              </Pill>
            ))}
          </div>
        </SectionCard>

        {/* Games */}
        <SectionCard
          index={3}
          title="Juegos a vigilar"
          icon={<Boxes className="h-5 w-5" />}
          note="Añade tantos como quieras. Cada uno con su precio y sus preferencias."
          delay={250}
          className="mt-6"
        >
          {state.games.map((g, i) => (
            <GameCard
              key={g.id}
              game={g}
              index={i}
              errors={errors}
              onChange={(p) => setGame(g.id, p)}
              onRemove={() => removeGame(g.id)}
              canRemove={state.games.length > 1}
            />
          ))}
          <button
            type="button"
            onClick={addGame}
            className="flex w-full items-center justify-center gap-2 rounded-2xl border-2 border-dashed border-border bg-transparent py-4 font-semibold text-[hsl(var(--green))] transition-all hover:-translate-y-px hover:border-[hsl(var(--green))] hover:bg-[hsl(173_62%_95%)]"
          >
            <Plus className="h-5 w-5" /> Añadir otro juego
          </button>
        </SectionCard>

        {/* Classifier */}
        <SectionCard
          index={4}
          title="Filtro inteligente"
          icon={<Cpu className="h-5 w-5" />}
          note="Distingue juego base de expansiones y componentes sueltos. Si no sabes qué poner, deja los valores tal cual."
          delay={320}
          className="mt-6"
        >
          <div className="flex items-center justify-between gap-4 rounded-xl border-[1.5px] border-border bg-[hsl(200_24%_97%)] px-4 py-3.5">
            <div>
              <div className="flex items-center gap-2 text-[0.92rem] font-semibold">
                <Sparkles className="h-4 w-4 text-[hsl(var(--gold))]" /> Usar el modelo local (Ollama)
              </div>
              <p className="mt-0.5 text-[0.82rem] text-[hsl(var(--brown))]">Más preciso en casos dudosos. Si lo apagas, solo se usan reglas (más rápido).</p>
            </div>
            <Switch checked={state.classifier.useLlm} onCheckedChange={(v) => setClassifier({ useLlm: v })} className="data-[state=checked]:bg-[hsl(var(--green))]" />
          </div>

          <div className={"mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2 transition-opacity " + (state.classifier.useLlm ? "" : "opacity-50")}>
            <Field label="Modelo de Ollama">
              <Select value={state.classifier.model} onValueChange={(v) => setClassifier({ model: v })} disabled={!state.classifier.useLlm}>
                <SelectTrigger className={inputCls()}>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {MODELS.map((m) => (
                    <SelectItem key={m.value} value={m.value}>{m.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </Field>
            <Field label="Ante la duda">
              <Select value={state.classifier.onUnknown} onValueChange={(v) => setClassifier({ onUnknown: v as "base" | "drop" })}>
                <SelectTrigger className={inputCls()}>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="base">Dejar pasar (recomendado)</SelectItem>
                  <SelectItem value="drop">Descartar (menos ruido)</SelectItem>
                </SelectContent>
              </Select>
            </Field>
          </div>
        </SectionCard>

        {/* Enviar a Darío */}
        <SectionCard
          index={<Send className="h-4 w-4" />}
          title="Enviar a Darío"
          icon={<Mail className="h-5 w-5" />}
          note="Cuando termines, mándame tu configuración por correo con un clic. El archivo viaja adjunto de verdad."
          delay={390}
          className="mt-6"
        >
          <Field
            label="Tu nombre"
            required
            hint="Aparece en el asunto del correo y en el nombre del archivo."
            error={validated && !who ? "Escribe tu nombre." : undefined}
          >
            <Input
              ref={nameRef}
              value={state.name}
              onChange={(ev) => setName(ev.target.value)}
              placeholder="Ej. Marc"
              className={inputCls(validated && !who)}
            />
          </Field>

          <div className="mt-4 rounded-xl border-[1.5px] border-border bg-[hsl(200_24%_97%)] p-4 text-[0.86rem] leading-relaxed text-[hsl(var(--brown))]">
            Al pulsar, se abrirá una pestaña de <b className="text-[hsl(var(--green-deep))]">Gmail</b> con el correo ya redactado para{" "}
            <b className="text-[hsl(var(--green-deep))]">{RECIPIENT_EMAIL}</b>: asunto{" "}
            <b className="text-[hsl(var(--green-deep))]">{who ? subject : "ALERTA WALLAPOP …"}</b> y, en el cuerpo, el resumen y el contenido de{" "}
            <b className="text-[hsl(var(--green-deep))]">{filename}</b>. Solo tienes que revisarlo y pulsar <b>Enviar</b>.
          </div>

          <Button
            type="button"
            onClick={handleSend}
            className="mt-4 h-12 w-full gap-2 rounded-xl bg-[hsl(var(--terra))] text-[1rem] font-bold text-white shadow-[0_12px_26px_-12px_hsl(var(--terra)/.9)] transition-all hover:-translate-y-px hover:bg-[hsl(var(--terra-deep))]"
          >
            <Send className="h-5 w-5" /> Enviar a Darío
          </Button>

          {sent && (
            <p className="slidein mt-3 text-center text-[0.85rem] font-medium text-[hsl(var(--green))]">
              ✓ Se abrió Gmail en una pestaña nueva. Revisa el correo y pulsa Enviar.
            </p>
          )}
        </SectionCard>

        {/* Validation summary */}
        {validated && !result.ok && (
          <div ref={summaryRef} className="slidein mt-6 flex items-start gap-3 rounded-2xl border-[1.5px] border-[hsl(3_80%_84%)] bg-[hsl(3_85%_97%)] px-5 py-4 text-[0.92rem] font-medium text-destructive">
            <AlertTriangle className="mt-0.5 h-5 w-5 flex-none" />
            <div>
              <b>Falta por completar:</b> {problems.slice(0, 7).join(", ")}
              {problems.length > 7 ? "…" : "."}
            </div>
          </div>
        )}

        {/* Preview */}
        {showPreview && <YamlPreview yaml={yaml} />}
      </div>

      {/* Sticky action bar */}
      <div className="fixed inset-x-0 bottom-0 z-20 border-t border-border bg-white/95 px-5 py-4 shadow-[0_-10px_30px_-18px_rgba(20,45,55,.45)] backdrop-blur-md">
        <div className="mx-auto flex max-w-[840px] flex-wrap items-center justify-end gap-2.5">
          <span className="mr-auto flex items-center gap-2 text-[0.9rem] font-medium text-[hsl(var(--brown))]">
            <Meeple className="h-4 w-4" />
            <b className="text-[hsl(var(--green-deep))]">{gameCount}</b> {gameCount === 1 ? "juego" : "juegos"}
          </span>
          <Button type="button" variant="outline" onClick={() => setShowPreview((v) => !v)} className="h-11 gap-2 rounded-xl border-border bg-[hsl(200_24%_96%)] font-semibold text-[hsl(var(--green-deep))] hover:bg-white">
            {showPreview ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
            <span className="hidden sm:inline">{showPreview ? "Ocultar" : "Ver archivo"}</span>
          </Button>
          <Button type="button" variant="outline" onClick={handleCopy} className="h-11 gap-2 rounded-xl border-border bg-[hsl(200_24%_96%)] font-semibold text-[hsl(var(--green-deep))] hover:bg-white">
            <Copy className="h-4 w-4" /> <span className="hidden sm:inline">Copiar</span>
          </Button>
          <Button type="button" variant="outline" onClick={handleDownload} title={"Descargar " + filename} className="h-11 gap-2 rounded-xl border-border bg-[hsl(200_24%_96%)] font-semibold text-[hsl(var(--green-deep))] hover:bg-white">
            <Download className="h-4 w-4" /> <span className="hidden sm:inline">Descargar</span>
          </Button>
          <Button
            type="button"
            onClick={handleSend}
            className="h-11 gap-2 rounded-xl bg-[hsl(var(--terra))] px-5 font-bold text-white shadow-[0_10px_24px_-10px_hsl(var(--terra)/.85)] transition-all hover:-translate-y-px hover:bg-[hsl(var(--terra-deep))]"
          >
            <Send className="h-4 w-4" /> Enviar a Darío
          </Button>
        </div>
      </div>
    </div>
  );
}

function Disclosure({ label, children }: { label: string; children: React.ReactNode }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="mt-5 border-t border-dashed border-border pt-4">
      <button type="button" onClick={() => setOpen((v) => !v)} className="flex items-center gap-2 text-[0.9rem] font-semibold text-[hsl(var(--brown))] transition-colors hover:text-[hsl(var(--green))]">
        <span className={"inline-block transition-transform " + (open ? "rotate-90" : "")}>▸</span>
        {label}
      </button>
      {open && <div className="slidein mt-4">{children}</div>}
    </div>
  );
}
