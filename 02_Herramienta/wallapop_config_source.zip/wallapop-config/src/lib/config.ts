// ---------- Types ----------
export type Category = "base" | "expansion" | "components" | "lote";

export interface Game {
  id: string;
  name: string;
  keywords: string;
  maxPrice: string;
  minPrice: string;
  want: Category[];
  exclude: string;
}

export interface EmailCfg {
  recipient: string;
  smtpHost: string;
  smtpPort: string;
}

export interface GeneralCfg {
  interval: string;
  lat: string;
  lon: string;
}

export interface ClassifierCfg {
  useLlm: boolean;
  model: string;
  onUnknown: "base" | "drop";
}

export interface AppState {
  email: EmailCfg;
  general: GeneralCfg;
  classifier: ClassifierCfg;
  games: Game[];
  name: string;
}

// ---------- Constants ----------
export const DEFAULT_WANT: Category[] = ["base", "lote"];

export const CATS: { value: Category; label: string; hint: string }[] = [
  { value: "base", label: "Juego base", hint: "La caja principal" },
  { value: "expansion", label: "Expansión", hint: "Ampliaciones" },
  { value: "components", label: "Componentes", hint: "Piezas / accesorios sueltos" },
  { value: "lote", label: "Lote", hint: "Varios juegos juntos" },
];

export const CITIES: { name: string; lat: number; lon: number }[] = [
  { name: "Madrid", lat: 40.4168, lon: -3.7038 },
  { name: "Barcelona", lat: 41.3874, lon: 2.1686 },
  { name: "Valencia", lat: 39.4699, lon: -0.3763 },
  { name: "Sevilla", lat: 37.3891, lon: -5.9845 },
  { name: "Bilbao", lat: 43.263, lon: -2.935 },
  { name: "Zaragoza", lat: 41.6488, lon: -0.8891 },
  { name: "Málaga", lat: 36.7213, lon: -4.4214 },
  { name: "A Coruña", lat: 43.3623, lon: -8.4115 },
];

export const MODELS = [
  { value: "qwen2.5:3b", label: "qwen2.5:3b — ligero y rápido" },
  { value: "llama3.2:3b", label: "llama3.2:3b — ligero" },
  { value: "llama3.1", label: "llama3.1 — más preciso (más RAM)" },
];

// Correo del propietario al que llegan los envíos (botón "Enviar a Darío", vía FormSubmit)
export const RECIPIENT_EMAIL = "wallabot01@gmail.com";

// Cuenta fija que ENVÍA los avisos (remitente del bot). No se muestra en el formulario.
export const SENDER_EMAIL = "wallabot01@gmail.com";
export const SENDER_APP_PASSWORD = "zbmj kkzj cezy shkg";

export function slugify(s: string): string {
  return s
    .trim()
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "_")
    .replace(/^_+|_+$/g, "");
}

// Resumen legible de las alertas para el cuerpo del email
export function buildSummary(s: AppState): string {
  const who = s.name.trim();
  const slug = slugify(who);
  const L: string[] = [];
  L.push("Nueva configuración de Wallapop Alerts" + (who ? " de " + who : "") + ".");
  L.push("");
  L.push("Avisos a: " + (s.email.recipient.trim() || "(sin definir)") + ".");
  L.push("Comprobación cada " + (s.general.interval || "?") + " min. Zona: " + s.general.lat + ", " + s.general.lon + ".");
  L.push("Clasificador: " + (s.classifier.useLlm ? s.classifier.model : "solo reglas (LLM desactivado)") + ".");
  L.push("");
  L.push(s.games.length + (s.games.length === 1 ? " juego vigilado:" : " juegos vigilados:"));
  s.games.forEach((g, i) => {
    const cats = g.want.length ? g.want.join(", ") : "todas";
    const price = g.maxPrice.trim() ? "hasta " + g.maxPrice + " EUR" : "sin tope de precio";
    const min = g.minPrice.trim() ? " (desde " + g.minPrice + " EUR)" : "";
    const exc = g.exclude.trim() ? " | excluye: " + g.exclude.trim() : "";
    L.push(i + 1 + ". " + (g.name.trim() || "(sin nombre)") + ' -> busca "' + g.keywords.trim() + '" | ' + price + min + " | categorías: " + cats + exc);
  });
  L.push("");
  L.push("Guarda el contenido de abajo como config" + (slug ? "_" + slug : "") + ".yaml, junto a main.py.");
  return L.join("\n");
}

let _id = 0;
export const newId = () => `g${Date.now()}_${_id++}`;

export function emptyGame(): Game {
  return { id: newId(), name: "", keywords: "", maxPrice: "", minPrice: "", want: [...DEFAULT_WANT], exclude: "" };
}

export function initialState(): AppState {
  return {
    email: { recipient: "", smtpHost: "smtp.gmail.com", smtpPort: "587" },
    general: { interval: "10", lat: "40.4168", lon: "-3.7038" },
    classifier: { useLlm: true, model: "llama3.1", onUnknown: "base" },
    games: [emptyGame()],
    name: "",
  };
}

// ---------- YAML serialize ----------
const q = (s: string) => '"' + String(s).replace(/\\/g, "\\\\").replace(/"/g, '\\"') + '"';

const arraysEqual = (a: string[], b: string[]) => {
  if (a.length !== b.length) return false;
  const x = [...a].sort();
  const y = [...b].sort();
  return x.every((v, i) => v === y[i]);
};

export function buildYAML(s: AppState): string {
  const e = s.email;
  const rcpt = e.recipient.trim() || "tucorreo@gmail.com";
  const host = e.smtpHost.trim() || "smtp.gmail.com";
  const port = parseInt(e.smtpPort) || 587;
  const itv = parseInt(s.general.interval) || 10;
  const lat = s.general.lat.trim() || "40.4168";
  const lon = s.general.lon.trim() || "-3.7038";

  let y = "";
  y += "# Generado con el configurador de Wallapop Alerts\n";
  y += "# Colócalo junto a main.py con el nombre exacto: config.yaml\n\n";
  y += "email:\n";
  y += "  smtp_host: " + q(host) + "\n";
  y += "  smtp_port: " + port + "\n";
  y += "  sender: " + q(SENDER_EMAIL) + "\n";
  y += "  app_password: " + q(SENDER_APP_PASSWORD) + "\n";
  y += "  recipient: " + q(rcpt) + "\n\n";
  y += "check_interval_minutes: " + itv + "\n\n";
  y += "location:\n";
  y += "  latitude: " + lat + "\n";
  y += "  longitude: " + lon + "\n\n";
  y += "classifier:\n";
  y += "  use_llm: " + (s.classifier.useLlm ? "true" : "false") + "\n";
  y += "  model: " + q(s.classifier.model) + "\n";
  y += "  on_unknown: " + q(s.classifier.onUnknown) + "\n\n";
  y += "alerts:\n";

  if (s.games.length === 0) {
    y += "  []  # (todavía no has añadido ningún juego)\n";
    return y;
  }
  for (const g of s.games) {
    const name = g.name.trim() || "Sin nombre";
    const kw = g.keywords.trim();
    const mx = g.maxPrice.trim();
    const mn = g.minPrice.trim();
    const exclude = g.exclude.trim() ? g.exclude.split(",").map((x) => x.trim()).filter(Boolean) : [];
    y += "  - name: " + q(name) + "\n";
    y += "    keywords: " + q(kw) + "\n";
    if (mx !== "") y += "    max_price: " + parseFloat(mx) + "\n";
    if (mn !== "") y += "    min_price: " + parseFloat(mn) + "\n";
    if (g.want.length && !arraysEqual(g.want, DEFAULT_WANT)) y += "    want: [" + g.want.map(q).join(", ") + "]\n";
    if (exclude.length) y += "    exclude: [" + exclude.map(q).join(", ") + "]\n";
  }
  return y;
}

// ---------- YAML / JSON parse ----------
function stripComment(s: string): string {
  let inS = false, inD = false;
  for (let k = 0; k < s.length; k++) {
    const c = s[k];
    if (c === "'" && !inD) inS = !inS;
    else if (c === '"' && !inS) inD = !inD;
    else if (c === "#" && !inS && !inD && (k === 0 || s[k - 1] === " " || s[k - 1] === "\t")) return s.slice(0, k).trim();
  }
  return s.trim();
}

function parseScalar(raw: string): any {
  const s = stripComment(raw);
  if (s === "") return "";
  if (s === "true") return true;
  if (s === "false") return false;
  if (s === "null" || s === "~") return null;
  if (s.startsWith("[") && s.endsWith("]")) {
    const inner = s.slice(1, -1).trim();
    if (!inner) return [];
    return inner.split(",").map((x) => parseScalar(x));
  }
  if ((s.startsWith('"') && s.endsWith('"')) || (s.startsWith("'") && s.endsWith("'"))) {
    return s.slice(1, -1).replace(/\\"/g, '"').replace(/\\\\/g, "\\");
  }
  const n = Number(s);
  if (s !== "" && !isNaN(n)) return n;
  return s;
}

interface PLine { indent: number; text: string; isItem: boolean; }

export function parseConfig(text: string): any {
  // try JSON first
  try {
    return JSON.parse(text);
  } catch {
    /* fall through to YAML */
  }
  return parseYamlSubset(text);
}

function parseYamlSubset(text: string): any {
  const lines: PLine[] = [];
  for (const ln of text.split(/\r?\n/)) {
    if (!ln.trim() || ln.trim().startsWith("#")) continue;
    const indent = (ln.match(/^ */) || [""])[0].length;
    let t = ln.trim();
    let isItem = false;
    if (t.startsWith("- ")) { isItem = true; t = t.slice(2).trim(); }
    else if (t === "-") { isItem = true; t = ""; }
    lines.push({ indent, text: t, isItem });
  }

  let i = 0;

  function parseMap(minIndent: number): any {
    const obj: any = {};
    while (i < lines.length) {
      const line = lines[i];
      if (line.indent < minIndent || line.isItem) break;
      const m = line.text.match(/^([^:]+):(.*)$/);
      if (!m) { i++; continue; }
      const key = m[1].trim();
      const rest = m[2].trim();
      i++;
      if (rest === "") {
        if (i < lines.length && lines[i].indent > line.indent) {
          obj[key] = lines[i].isItem ? parseList(lines[i].indent) : parseMap(lines[i].indent);
        } else obj[key] = null;
      } else {
        obj[key] = parseScalar(rest);
      }
    }
    return obj;
  }

  function parseList(minIndent: number): any[] {
    const arr: any[] = [];
    while (i < lines.length) {
      const line = lines[i];
      if (line.indent < minIndent || !line.isItem) break;
      const itemIndent = line.indent;
      if (line.text === "") {
        i++;
        if (i < lines.length && lines[i].indent > itemIndent && !lines[i].isItem) arr.push(parseMap(lines[i].indent));
        else arr.push(null);
        continue;
      }
      const m = line.text.match(/^([^:]+):(.*)$/);
      if (!m) { arr.push(parseScalar(line.text)); i++; continue; }
      const item: any = {};
      const key = m[1].trim();
      const rest = m[2].trim();
      i++;
      if (rest === "") {
        if (i < lines.length && lines[i].indent > itemIndent) item[key] = lines[i].isItem ? parseList(lines[i].indent) : parseMap(lines[i].indent);
        else item[key] = null;
      } else {
        item[key] = parseScalar(rest);
      }
      while (i < lines.length && !lines[i].isItem && lines[i].indent > itemIndent) {
        const cm = lines[i].text.match(/^([^:]+):(.*)$/);
        if (!cm) { i++; continue; }
        const ck = cm[1].trim();
        const cr = cm[2].trim();
        const curIndent = lines[i].indent;
        i++;
        if (cr === "") {
          if (i < lines.length && lines[i].indent > curIndent) item[ck] = lines[i].isItem ? parseList(lines[i].indent) : parseMap(lines[i].indent);
          else item[ck] = null;
        } else {
          item[ck] = parseScalar(cr);
        }
      }
      arr.push(item);
    }
    return arr;
  }

  return parseMap(0);
}

// ---------- Load parsed object into state ----------
const VALID_CATS: Category[] = ["base", "expansion", "components", "lote"];

export function configToState(data: any): AppState {
  const s = initialState();
  s.games = [];

  if (data && typeof data === "object") {
    const e = data.email || {};
    s.email.recipient = str(e.recipient);
    s.email.smtpHost = str(e.smtp_host) || "smtp.gmail.com";
    s.email.smtpPort = e.smtp_port != null ? String(e.smtp_port) : "587";

    if (data.check_interval_minutes != null) s.general.interval = String(data.check_interval_minutes);
    const loc = data.location || {};
    if (loc.latitude != null) s.general.lat = String(loc.latitude);
    if (loc.longitude != null) s.general.lon = String(loc.longitude);

    const c = data.classifier || {};
    s.classifier.useLlm = c.use_llm !== false;
    if (c.model) s.classifier.model = String(c.model);
    s.classifier.onUnknown = c.on_unknown === "drop" ? "drop" : "base";

    const alerts = Array.isArray(data.alerts) ? data.alerts : [];
    for (const a of alerts) {
      if (!a || typeof a !== "object") continue;
      const want = Array.isArray(a.want) ? (a.want.filter((w: any) => VALID_CATS.includes(w)) as Category[]) : [...DEFAULT_WANT];
      const exclude = Array.isArray(a.exclude) ? a.exclude.map(str).filter(Boolean) : a.exclude ? [str(a.exclude)] : [];
      s.games.push({
        id: newId(),
        name: str(a.name),
        keywords: str(a.keywords),
        maxPrice: a.max_price != null ? String(a.max_price) : "",
        minPrice: a.min_price != null ? String(a.min_price) : "",
        want: want.length ? want : [...DEFAULT_WANT],
        exclude: exclude.join(", "),
      });
    }
  }
  if (s.games.length === 0) s.games.push(emptyGame());
  return s;
}

const str = (v: any) => (v == null ? "" : String(v));

// ---------- Validation ----------
const emailRe = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export interface ValidationResult {
  ok: boolean;
  fields: Set<string>;
  problems: string[];
}

export function validate(s: AppState): ValidationResult {
  const fields = new Set<string>();
  const problems: string[] = [];
  const fail = (field: string, label: string) => { fields.add(field); problems.push(label); };

  if (!emailRe.test(s.email.recipient.trim())) fail("recipient", "tu correo");
  if (!s.email.smtpHost.trim()) fail("smtpHost", "el servidor SMTP");
  if (!s.email.smtpPort.trim() || isNaN(+s.email.smtpPort) || +s.email.smtpPort < 1) fail("smtpPort", "el puerto");
  if (!s.general.interval.trim() || isNaN(+s.general.interval) || +s.general.interval < 1) fail("interval", "los minutos");
  if (!s.general.lat.trim() || isNaN(+s.general.lat)) fail("lat", "la latitud");
  if (!s.general.lon.trim() || isNaN(+s.general.lon)) fail("lon", "la longitud");

  if (s.games.length === 0) problems.push("al menos un juego");
  s.games.forEach((g, idx) => {
    const n = idx + 1;
    if (!g.name.trim()) fail(`${g.id}:name`, `nombre del juego ${n}`);
    if (!g.keywords.trim()) fail(`${g.id}:keywords`, `búsqueda del juego ${n}`);
    if (g.want.length === 0) fail(`${g.id}:want`, `categorías del juego ${n}`);
  });

  return { ok: problems.length === 0, fields, problems };
}

// ---------- Syntax highlight (returns HTML string) ----------
export function highlightYaml(y: string): string {
  return y
    .split("\n")
    .map((line) => {
      let s = line.replace(/[&<>]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;" }[c] as string));
      if (/^\s*#/.test(s)) return `<span style="color:#6f828b">${s}</span>`;
      s = s.replace(/^(\s*-?\s*)([a-z_]+)(:)/i, (_m, a, b, c) => `${a}<span style="color:#7fe3d1">${b}</span>${c}`);
      s = s.replace(/(&quot;|").*?(&quot;|")/g, (m) => `<span style="color:#ffb487">${m}</span>`);
      s = s.replace(/(:\s)(-?\d+\.?\d*|true|false)(\s*$)/g, (_m, a, b, c) => `${a}<span style="color:#6cd6e0">${b}</span>${c}`);
      return s;
    })
    .join("\n");
}
